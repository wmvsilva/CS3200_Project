William Silva, Nathan Paradis
Professor Durant
CS3200
7 December 2015

##########################################

complete_schema.sql - Contains the complete structure of the database as
exported by MySQL.

data_dump.sql - Contains all sample data as exported by MySQL

src - Folder containing all SQL source files manually created, except for
the data_loader.sql file which was generated from CSVs using a script.

